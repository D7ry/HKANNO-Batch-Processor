
int ExecuteHctFilterManager(char *ifile);
